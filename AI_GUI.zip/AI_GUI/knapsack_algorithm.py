import random

# Hàm sinh dữ liệu bài toán
def generate_knapsack_problem(num_items, max_weight=20):
    values = [random.randint(1, 100) for _ in range(num_items)]
    weights = [random.randint(1, max_weight) for _ in range(num_items)]
    capacity = int(sum(weights) * 0.6)
    return values, weights, capacity

# Hàm Quay lui cơ bản
def knapsack_backtracking_tracking(weights, values, capacity, n, selected=None, best=None, fitness_tracker=None):
    if selected is None:
        selected = [0] * len(weights)
    if best is None:
        best = {"value": 0, "weight": 0, "solution": [0] * len(weights), "branches": 0}
    if fitness_tracker is None:
        fitness_tracker = []

    # Tăng số lượng nhánh được duyệt
    best["branches"] += 1

    # Lưu giá trị tốt nhất hiện tại
    fitness_tracker.append(max(fitness_tracker[-1], best["value"]) if fitness_tracker else best["value"])

    # Điều kiện dừng
    if n == 0 or capacity == 0:
        current_value = sum(values[i] for i in range(len(weights)) if selected[i] == 1)
        current_weight = sum(weights[i] for i in range(len(weights)) if selected[i] == 1)
        if current_value > best["value"]:
            best["value"] = current_value
            best["weight"] = current_weight
            best["solution"] = selected[:]
            
        return best

    # Không chọn vật phẩm thứ n
    selected[n - 1] = 0
    knapsack_backtracking_tracking(weights, values, capacity, n - 1, selected, best, fitness_tracker)

    # Chọn vật phẩm thứ n (nếu có thể)
    if weights[n - 1] <= capacity:
        selected[n - 1] = 1
        knapsack_backtracking_tracking(weights, values, capacity - weights[n - 1], n - 1, selected, best, fitness_tracker)

    return best