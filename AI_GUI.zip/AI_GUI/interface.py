import tkinter as tk
from tkinter import ttk
from knapsack_algorithm import generate_knapsack_problem, knapsack_backtracking_tracking
from draw import draw_tree

# Hàm hiển thị kết quả
def show_results():
    try:
        num_items = int(entry_num_items.get())
        if num_items <= 0:
            raise ValueError("Số lượng vật phẩm phải lớn hơn 0.")
        
        # Sinh dữ liệu bài toán
        values, weights, capacity = generate_knapsack_problem(num_items)
        
        # Hiển thị kết quả
        result_text.set(
            f"Giá trị các vật phẩm: {values}\n"
            f"Trọng lượng các vật phẩm: {weights}\n"
            f"Giới hạn trọng lượng túi: {capacity}"
        )

        # Kết quả từ thuật toán quay lui
        fitness_tracker_backtracking = []
        result_backtracking = knapsack_backtracking_tracking(weights, values, capacity, len(weights), fitness_tracker=fitness_tracker_backtracking)
        selected_result = result_backtracking["solution"]

        # Cập nhật nhãn tổng giá trị và tổng cân nặng
        result_label.config(text=str(result_backtracking["solution"]))
        total_value_label.config(text=str(result_backtracking["value"]))
        total_weight_label.config(text=str(result_backtracking["weight"]))

        # Vẽ cây với kết quả đã chọn
        draw_tree(canvas, num_items, values, selected_result)

    except ValueError as e:
        result_text.set(f"Lỗi: {e}")

# Tạo giao diện
root = tk.Tk()
root.title("Knapsack Problem Generator")

# Khung trên: Chứa 2 phần ngang
frame_top = tk.Frame(root, bg="#f1f3f4", padx=10, pady=10)
frame_top.pack(fill=tk.X)

# Khung trái: Nhập liệu và nút
frame_top_left = tk.Frame(frame_top, bg="#f8d7da", padx=10, pady=10)
frame_top_left.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

# Nhập liệu: Entry cho số lượng vật phẩm
tk.Label(frame_top_left, text="Số lượng vật phẩm", bg="#f8d7da", font=("Arial", 10)).pack(anchor="w", pady=5)
entry_num_items = ttk.Entry(frame_top_left, width=10)
entry_num_items.pack(anchor="w", pady=5)

# Nút "Sinh bài toán"
btn_generate = tk.Button(frame_top_left, text="Sinh bài toán", bg="#f8d7da", padx=10, pady=5, command=show_results)
btn_generate.pack(anchor="w", pady=5)

# Khung phải: Kết quả
frame_top_right = tk.Frame(frame_top, bg="#e9ecef", padx=10, pady=10)
frame_top_right.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

# Nhãn kết quả
tk.Label(frame_top_right, text="Kết quả", bg="#e9ecef", font=("Arial", 10, "bold"), fg="blue").pack(anchor="w", pady=5)

# Hiển thị kết quả
result_text = tk.StringVar()
result_display = tk.Label(frame_top_right, textvariable=result_text, font=("Arial", 12), bg="white", fg="black", justify="left")
result_display.pack(fill=tk.BOTH, expand=True)

# Khung giua để hiển thị tổng giá trị và tổng cân nặng
frame_summary = tk.Frame(root, bg="#f1f3f4", padx=10, pady=10)
frame_summary.pack(fill=tk.X)

# Hiển thị giải pháp
tk.Label(frame_summary, text="Giải pháp:", bg="#f1f3f4", font=("Arial", 10, "bold")).pack(side=tk.LEFT, padx=5)
result_label = tk.Label(frame_summary, text="0", bg="#f1f3f4", font=("Arial", 10))
result_label.pack(side=tk.LEFT, padx=5)

# Hiển thị tổng giá trị
tk.Label(frame_summary, text="Tổng giá trị:", bg="#f1f3f4", font=("Arial", 10, "bold")).pack(side=tk.LEFT, padx=5)
total_value_label = tk.Label(frame_summary, text="0", bg="#f1f3f4", font=("Arial", 10))
total_value_label.pack(side=tk.LEFT, padx=5)

# Hiển thị tổng cân nặng
tk.Label(frame_summary, text="Tổng cân nặng:", bg="#f1f3f4", font=("Arial", 10, "bold")).pack(side=tk.LEFT, padx=20)
total_weight_label = tk.Label(frame_summary, text="0", bg="#f1f3f4", font=("Arial", 10))
total_weight_label.pack(side=tk.LEFT, padx=5)

# Khung dưới: Hiển thị sơ đồ cây
frame_bottom = tk.Frame(root, bg="#f8f9fa", padx=10, pady=10)
frame_bottom.pack(fill=tk.BOTH, expand=True)

# Canvas để vẽ sơ đồ cây
canvas = tk.Canvas(frame_bottom, bg="white", width=600, height=400)
canvas.pack(fill=tk.BOTH, expand=True)

# Chạy giao diện
root.mainloop()