def draw_node(canvas, x, y, text, is_selected, parent_selected):
    """Hàm vẽ một nút với màu sắc tùy thuộc vào trạng thái"""
    color = "lightgreen" if is_selected and parent_selected else "lightgray"  # Chọn màu dựa trên trạng thái
    canvas.create_oval(x - 20, y - 20, x + 20, y + 20, fill=color)
    canvas.create_text(x, y, text=text)

def draw_subtree(canvas, x, y, remaining_items, level, level_height, node_radius, values, selected, h_spacing, parent_selected):
    """Hàm vẽ cây nhị phân với hai nhánh tại mỗi nút."""
    if remaining_items == 0:
        return

    current_value = values[len(values) - remaining_items]

    # Tính toán trạng thái hiện tại
    is_selected = selected[len(selected) - remaining_items] == 1

    # Tính toán tọa độ các nhánh con
    left_x = x - h_spacing
    right_x = x + h_spacing
    next_y = y + level_height

    if parent_selected == True:
        # Vẽ nhánh "Chọn"
        draw_node(canvas, left_x, next_y, f"{current_value}", is_selected, parent_selected)
        canvas.create_line(x, y + node_radius, left_x, next_y - node_radius)
        draw_subtree(canvas, left_x, next_y, remaining_items - 1, level + 1, level_height, node_radius, values, selected, h_spacing // 2, is_selected)

        # Vẽ nhánh "Không chọn"
        draw_node(canvas, right_x, next_y, "0", not is_selected, parent_selected)
        canvas.create_line(x, y + node_radius, right_x, next_y - node_radius)
        draw_subtree(canvas, right_x, next_y, remaining_items - 1, level + 1, level_height, node_radius, values, selected, h_spacing // 2, not is_selected)
    else:
        # Vẽ nhánh "Chọn"
        draw_node(canvas, left_x, next_y, f"{current_value}", is_selected, parent_selected)
        canvas.create_line(x, y + node_radius, left_x, next_y - node_radius)
        draw_subtree(canvas, left_x, next_y, remaining_items - 1, level + 1, level_height, node_radius, values, selected, h_spacing // 2, parent_selected)

        # Vẽ nhánh "Không chọn"
        draw_node(canvas, right_x, next_y, "0",not is_selected, parent_selected)
        canvas.create_line(x, y + node_radius, right_x, next_y - node_radius)
        draw_subtree(canvas, right_x, next_y, remaining_items - 1, level + 1, level_height, node_radius, values, selected, h_spacing // 2, parent_selected)


def draw_tree(canvas, num_items, values, selected):
    """Hàm vẽ cây nhị phân đầy đủ."""
    # Xóa cây cũ trước khi vẽ lại
    canvas.delete("all")
    
    if num_items == 0:
        return

    # Tọa độ gốc
    width = 1500
    x = width // 2
    y = 50
    level_height = 80
    node_radius = 20
    h_spacing = width // 4 

    draw_node(canvas, x, y, "Start", is_selected=True, parent_selected=True)
    draw_subtree(canvas, x, y, num_items, 1, level_height, node_radius, values, selected, h_spacing, parent_selected=True)
